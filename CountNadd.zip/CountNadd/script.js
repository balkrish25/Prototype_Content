// ===================== ELEMENTS =====================
const pages = {
  home: document.getElementById("home"),
  question: document.getElementById("question"),
  result: document.getElementById("result"),
  final: document.getElementById("final")
};

const startBtn = document.getElementById("startBtn");
const objectsContainer = document.getElementById("objectsContainer");
const optionsContainer = document.getElementById("optionsContainer");
const resultText = document.getElementById("resultText");
const resultBtn = document.getElementById("resultBtn");
const homeBtns = document.querySelectorAll(".home-btn");
const homeFinalBtn = document.getElementById("homeFinalBtn");
const starsContainer = document.getElementById("starsContainer");

// ===================== AUDIO ELEMENTS =====================
const startAudio = document.getElementById("startAudio");
const correctAudio = document.getElementById("correctAudio");
const wrongAudio = document.getElementById("wrongAudio");
const finalAudio = document.getElementById("finalAudio");

// Helper: stop all audio before playing new one
function stopAllAudio() {
  [startAudio, correctAudio, wrongAudio, finalAudio].forEach(a => {
    a.pause();
    a.currentTime = 0;
  });
}

// Helper: play a specific audio safely
function playAudio(audio) {
  stopAllAudio();
  audio.currentTime = 0;
  audio.play().catch(() => {}); // avoid browser autoplay issues
}

let currentQuestion = 0;
let correctAnswers = 0;

// ===================== QUESTIONS =====================
const questions = [
  { layout: "horizontal", box1: { count: 1, size: "large" },  box2: { count: 1, size: "large" },  answer: 2, options: [3, 5, 2, 1], image: "assets/cycle.png" },
  { layout: "vertical",   box1: { count: 2, size: "medium" }, box2: { count: 2, size: "medium" }, answer: 4, options: [2, 4, 5, 6], image: "assets/eraser.png" },
  { layout: "vertical",   box1: { count: 3, size: "medium" }, box2: { count: 2, size: "medium" }, answer: 5, options: [6, 7, 5, 4], image: "assets/pen.png" },
  { layout: "vertical",   box1: { count: 2, size: "medium" }, box2: { count: 1, size: "medium" }, answer: 3, options: [3, 2, 7, 4], image: "assets/football.png" },
  { layout: "vertical",   box1: { count: 4, size: "small" },  box2: { count: 3, size: "small" },  answer: 7, options: [8, 7, 9, 6], image: "assets/balloon.png" },
  { layout: "vertical",   box1: { count: 4, size: "small" },  box2: { count: 4, size: "small" },  answer: 8, options: [9, 6, 7, 8], image: "assets/pencil.png" }
];

// ===================== PAGE CONTROL =====================
function showPage(name) {
  Object.values(pages).forEach(p => p.classList.remove("active"));
  pages[name].classList.add("active");
  starsContainer.style.display = (name === "question" || name === "result") ? "flex" : "none";
}

// ===================== OPTION STYLES =====================
// Define a set of unique styles for each option button
const optionStyles = [
  { backgroundColor: "#fdf39b", outlineColor: "#fdf39b" },  // Option 1
  { backgroundColor: "#ead9c8", outlineColor: "#ead9c8" },  // Option 2
  { backgroundColor: "#debcf5", outlineColor: "#debcf5" },  // Option 3
  { backgroundColor: "#c5e2ee", outlineColor: "#c5e2ee" },  // Option 4
];

// ===================== QUESTION SETUP =====================
function loadQuestion() {
  const q = questions[currentQuestion];
  objectsContainer.innerHTML = "";
  optionsContainer.innerHTML = "";

  objectsContainer.className = "objects " + (q.layout === "vertical" ? "vertical-layout" : "horizontal-layout");

  const box1 = createObjectBox(q.image, q.box1.count, q.box1.size);
  const plus = createPlusSign();
  const box2 = createObjectBox(q.image, q.box2.count, q.box2.size);

  objectsContainer.append(box1, plus, box2);

  q.options.forEach((opt, index) => {
    const btn = document.createElement("button");
    btn.textContent = opt;
    btn.onclick = () => checkAnswer(opt === q.answer);

    // Apply the unique styles for each option
    btn.style.backgroundColor = optionStyles[index].backgroundColor;
    btn.style.outline = `2px solid ${optionStyles[index].outlineColor}`;  // Ensure outline is properly applied
    
    optionsContainer.appendChild(btn);
  });
}

function createObjectBox(imageSrc, count, sizeClass) {
  const box = document.createElement("div");
  box.className = "object-box";
  for (let i = 0; i < count; i++) {
    const img = document.createElement("img");
    img.src = imageSrc;
    img.alt = "Object";
    img.classList.add("object-img", sizeClass);
    box.appendChild(img);
  }
  return box;
}

function createPlusSign() {
  const plus = document.createElement("img");
  plus.src = "assets/plus.png";
  plus.className = "plus-sign";
  plus.alt = "Plus";
  return plus;
}

// ===================== CHECK ANSWER =====================
function checkAnswer(isCorrect) {
  showPage("result");

  if (isCorrect) {
    resultText.textContent = "Good!";
    resultText.style.color = "#009800"; // Change the text color to green
    starsContainer.children[currentQuestion].src = "assets/star_filled.png";
    correctAnswers++;
    playAudio(correctAudio);
    resultBtn.textContent = "▶▶"; // Button shows Next
  } else {
    resultText.textContent = "Wrong!";
    resultText.style.color = "#cb0000"; // Change the text color to red
    playAudio(wrongAudio);
    resultBtn.textContent = "◀◀"; // Button shows Previous
  }

  resultBtn.onclick = () => {
    stopAllAudio(); // stop any sound before proceeding
    if (isCorrect) currentQuestion++;
    if (currentQuestion < questions.length) {
      showPage("question");
      loadQuestion();
    } else {
      showPage("final");
      playAudio(finalAudio);
    }
  };
}

// ===================== EVENT LISTENERS =====================
startBtn.onclick = () => {
  playAudio(startAudio);
  showPage("question");
  currentQuestion = 0;
  correctAnswers = 0;
  [...starsContainer.children].forEach(s => s.src = "assets/star_outline.png");
  loadQuestion();
};

homeBtns.forEach(btn => {
  btn.onclick = () => {
    playAudio(startAudio);
    showPage("home");
  };
});

homeFinalBtn.onclick = () => {
  playAudio(startAudio);
  showPage("home");
};
